"""
Calculate Dubins Curve between waypoints

author: Fischer, but I just copied the math from this paper:

fischergabbert@gmail.com

# some modifications added by Marc

"""

import matplotlib.pyplot as plt
import math
import numpy as np
from enum import Enum
from scipy.spatial import distance


class TurnType(Enum):
    LSL = 1
    LSR = 2
    RSL = 3
    RSR = 4
    RLR = 5
    LRL = 6


class Waypoint:

    def __init__(self, x, y, psi):
        self.x = x
        self.y = y
        self.psi = psi

    def __str__(self):
        return "x: " + str(self.x) + ", y: " + str(self.y) + ", psi: " + str(self.psi)


class Param:
    def __init__(self, p_init, seg_final, turn_radius, ):
        self.p_init = p_init
        self.seg_final = seg_final
        self.turn_radius = turn_radius
        self.type = 0


class Trajectory:
    def __init__(self, x, y):
        self.x = x
        self.y = y



def wrapTo2Pi(angle):
    posIn = angle > 0
    angle = angle % (2 * math.pi)
    if angle == 0 and posIn:
        angle = 2 * math.pi
    return angle


def wrapToPi(angle):
    q = (angle < -math.pi) or (math.pi < angle)
    if q:
        angle = wrapTo2Pi(angle + math.pi) - math.pi
    return angle


def headingToStandard(hdg):
    # Convert NED heading to standard unit circle...radians only for now (I'm lazy)
    thet = wrapTo2Pi(math.pi/2 - wrapToPi(hdg))
    return thet


def calcDubinsPath(wpt1, wpt2, radius):
    # Calculate a dubins path between two waypoints
    param = Param(wpt1, 0, 0)
    tz = [0, 0, 0, 0, 0, 0]
    pz = [0, 0, 0, 0, 0, 0]
    qz = [0, 0, 0, 0, 0, 0]
    param.seg_final = [0, 0, 0]
    # Convert the headings from NED to standard unit cirlce, and then to radians
    psi1 = headingToStandard(wpt1.psi)
    psi2 = headingToStandard(wpt2.psi)

    # Do math
    param.turn_radius = radius
    dx = wpt2.x - wpt1.x
    dy = wpt2.y - wpt1.y
    D = math.sqrt(dx * dx + dy * dy)
    d = D / param.turn_radius  # Normalize by turn radius...makes length calculation easier down the road.

    # Angles defined in the paper
    theta = math.atan2(dy, dx) % (2 * math.pi)
    alpha = (psi1 - theta) % (2 * math.pi)
    beta = (psi2 - theta) % (2 * math.pi)
    best_word = -1
    best_cost = -1

    # Calculate all dubin's paths between points
    tz[0], pz[0], qz[0] = dubinsLSL(alpha, beta, d)
    tz[1], pz[1], qz[1] = dubinsLSR(alpha, beta, d)
    tz[2], pz[2], qz[2] = dubinsRSL(alpha, beta, d)
    tz[3], pz[3], qz[3] = dubinsRSR(alpha, beta, d)
    tz[4], pz[4], qz[4] = dubinsRLR(alpha, beta, d)
    tz[5], pz[5], qz[5] = dubinsLRL(alpha, beta, d)

    # Now, pick the one with the lowest cost
    for x in range(6):
        if (tz[x] != -1):
            cost = tz[x] + pz[x] + qz[x]
            if (cost < best_cost or best_cost == -1):
                best_word = x + 1
                best_cost = cost
                param.seg_final = [tz[x], pz[x], qz[x]]

    param.type = TurnType(best_word)
    return param


# Here's all of the dubins path math
def dubinsLSL(alpha, beta, d):
    tmp0 = d + math.sin(alpha) - math.sin(beta)
    tmp1 = math.atan2((math.cos(beta) - math.cos(alpha)), tmp0)
    p_squared = 2 + d * d - (2 * math.cos(alpha - beta)) + (2 * d * (math.sin(alpha) - math.sin(beta)))
    if p_squared < 0:
        p = -1
        q = -1
        t = -1
    else:
        t = (tmp1 - alpha) % (2 * math.pi)
        p = math.sqrt(p_squared)
        q = (beta - tmp1) % (2 * math.pi)
    return t, p, q


def dubinsRSR(alpha, beta, d):
    tmp0 = d - math.sin(alpha) + math.sin(beta)
    tmp1 = math.atan2((math.cos(alpha) - math.cos(beta)), tmp0)
    p_squared = 2 + d * d - (2 * math.cos(alpha - beta)) + 2 * d * (math.sin(beta) - math.sin(alpha))
    if p_squared < 0:
        p = -1
        q = -1
        t = -1
    else:
        t = (alpha - tmp1) % (2 * math.pi)
        p = math.sqrt(p_squared)
        q = (-1 * beta + tmp1) % (2 * math.pi)
    return t, p, q


def dubinsRSL(alpha, beta, d):
    tmp0 = d - math.sin(alpha) - math.sin(beta)
    p_squared = -2 + d * d + 2 * math.cos(alpha - beta) - 2 * d * (math.sin(alpha) + math.sin(beta))
    if p_squared < 0:
        p = -1
        q = -1
        t = -1
    else:
        p = math.sqrt(p_squared)
        tmp2 = math.atan2((math.cos(alpha) + math.cos(beta)), tmp0) - math.atan2(2, p)
        t = (alpha - tmp2) % (2 * math.pi)
        q = (beta - tmp2) % (2 * math.pi)
    return t, p, q


def dubinsLSR(alpha, beta, d):
    tmp0 = d + math.sin(alpha) + math.sin(beta)
    p_squared = -2 + d * d + 2 * math.cos(alpha - beta) + 2 * d * (math.sin(alpha) + math.sin(beta))
    if p_squared < 0:
        p = -1
        q = -1
        t = -1
    else:
        p = math.sqrt(p_squared)
        tmp2 = math.atan2((-1 * math.cos(alpha) - math.cos(beta)), tmp0) - math.atan2(-2, p)
        t = (tmp2 - alpha) % (2 * math.pi)
        q = (tmp2 - beta) % (2 * math.pi)
    return t, p, q


def dubinsRLR(alpha, beta, d):
    tmp_rlr = (6 - d * d + 2 * math.cos(alpha - beta) + 2 * d * (math.sin(alpha) - math.sin(beta))) / 8
    if (abs(tmp_rlr) > 1):
        p = -1
        q = -1
        t = -1
    else:
        p = (2 * math.pi - math.acos(tmp_rlr)) % (2 * math.pi)
        t = (alpha - math.atan2((math.cos(alpha) - math.cos(beta)), d - math.sin(alpha) + math.sin(beta)) + p / 2 % (
                    2 * math.pi)) % (2 * math.pi)
        q = (alpha - beta - t + (p % (2 * math.pi))) % (2 * math.pi)

    return t, p, q


def dubinsLRL(alpha, beta, d):
    tmp_lrl = (6 - d * d + 2 * math.cos(alpha - beta) + 2 * d * (-1 * math.sin(alpha) + math.sin(beta))) / 8
    if (abs(tmp_lrl) > 1):
        p = -1
        q = -1
        t = -1
    else:
        p = (2 * math.pi - math.acos(tmp_lrl)) % (2 * math.pi)
        t = (-1 * alpha - math.atan2((math.cos(alpha) - math.cos(beta)),
                                     d + math.sin(alpha) - math.sin(beta)) + p / 2) % (2 * math.pi)
        q = ((beta % (2 * math.pi)) - alpha - t + (p % (2 * math.pi))) % (2 * math.pi)
    return t, p, q


def dubins_traj(param, step):
    # Build the trajectory from the lowest-cost path
    x = 0
    i = 0
    length = (param.seg_final[0] + param.seg_final[1] + param.seg_final[2]) * param.turn_radius
    length = math.floor(length / step)
    path = -1 * np.ones((length, 4))

    while x < length:
        path[i] = dubins_path(param, x)
        x += step
        i += 1
    return path


def dubins_path(param, t):
    # Helper function for curve generation
    curvature = 1 / param.turn_radius
    tprime = t * curvature

    p_init = np.array([0, 0, headingToStandard(param.p_init.psi)])
    #
    L_SEG = 1
    S_SEG = 2
    R_SEG = 3
    DIRDATA = np.array([[L_SEG, S_SEG, L_SEG], [L_SEG, S_SEG, R_SEG], [R_SEG, S_SEG, L_SEG], [R_SEG, S_SEG, R_SEG],
                        [R_SEG, L_SEG, R_SEG], [L_SEG, R_SEG, L_SEG]])
    #
    types = DIRDATA[param.type.value - 1][:]
    param1 = param.seg_final[0]
    param2 = param.seg_final[1]
    mid_pt1 = dubins_segment(param1, p_init, types[0], curvature)
    mid_pt2 = dubins_segment(param2, mid_pt1, types[1], curvature)

    if (tprime < param1):
        end_pt = dubins_segment(tprime, p_init, types[0], curvature)
    elif (tprime < (param1 + param2)):
        end_pt = dubins_segment(tprime - param1, mid_pt1, types[1], curvature)
    else:
        end_pt = dubins_segment(tprime - param1 - param2, mid_pt2, types[2], curvature)

    end_pt[0] = end_pt[0] * param.turn_radius + param.p_init.x
    end_pt[1] = end_pt[1] * param.turn_radius + param.p_init.y
    end_pt[2] = end_pt[2] % (2 * math.pi)

    return end_pt


def dubins_segment(seg_param, seg_init, seg_type, curvature):
    # Helper function for curve generation
    L_SEG = 1
    S_SEG = 2
    R_SEG = 3
    seg_end = np.array([0.0, 0.0, 0.0, 0.0])
    if (seg_type == L_SEG):
        seg_end[0] = seg_init[0] + math.sin(seg_init[2] + seg_param) - math.sin(seg_init[2])
        seg_end[1] = seg_init[1] - math.cos(seg_init[2] + seg_param) + math.cos(seg_init[2])
        seg_end[2] = seg_init[2] + seg_param
        seg_end[3] = curvature
    elif (seg_type == R_SEG):
        seg_end[0] = seg_init[0] - math.sin(seg_init[2] - seg_param) + math.sin(seg_init[2])
        seg_end[1] = seg_init[1] + math.cos(seg_init[2] - seg_param) - math.cos(seg_init[2])
        seg_end[2] = seg_init[2] - seg_param
        seg_end[3] = -curvature
    elif (seg_type == S_SEG):
        seg_end[0] = seg_init[0] + math.cos(seg_init[2]) * seg_param
        seg_end[1] = seg_init[1] + math.sin(seg_init[2]) * seg_param
        seg_end[2] = seg_init[2]
        seg_end[3] = 0

    return seg_end

def get_multi_waypoint_from_np(array_of_waypoints, step):
    total_path = np.array([]).reshape(0, 4)
    for i in range(len(array_of_waypoints)-1):
        waypoint_from = Waypoint(array_of_waypoints[i, 0], array_of_waypoints[i, 1], array_of_waypoints[i, 2])
        waypoint_to = Waypoint(array_of_waypoints[i+1, 0], array_of_waypoints[i+1, 1], array_of_waypoints[i+1, 2])
        radius = array_of_waypoints[i, 3]
        param = calcDubinsPath(waypoint_from, waypoint_to, radius)
        path = dubins_traj(param, step)
        total_path = np.vstack([total_path, path])
    return total_path


def get_multi_waypoint(list_of_waypoints, radius, step):
    total_path = np.array([]).reshape(0, 4)
    for i in range(len(list_of_waypoints) - 1):
        param = calcDubinsPath(list_of_waypoints[i], list_of_waypoints[i + 1], radius)
        path = dubins_traj(param, step)
        total_path = np.vstack([total_path, path])
    return total_path

def fill_diagonal_band(matrix, band_width, value):
    band_diag = np.ones_like(matrix)
    band_diag = np.tril(band_diag, k=band_width)
    band_diag = np.triu(band_diag, k=-band_width)
    band_diag = band_diag == 1

    matrix[band_diag] = value

def is_path_valid(path, min_distance, step):
    # Extract the x, y coordinates from the path
    coordinates = path[:, :2]

    # Calculate the pairwise distance matrix
    dist_matrix = distance.cdist(coordinates, coordinates)

    # Fill the diagonal band to ignore consecutive points
    fill_diagonal_band(dist_matrix, band_width=int(min_distance/step), value=np.inf)

    # Check if any distances are less than the minimum distance
    if np.any(dist_matrix < min_distance):
        return False
    return True


def main():
    # User's waypoints: [x, y, heading (degrees)]
    pt1 = Waypoint(0, 0, 0)
    pt2 = Waypoint(60, 70, 3.1)
    pt3 = Waypoint(60, 30, 0)
    Wptz = [pt1, pt2, pt3]
    # Run the code
    i = 0

    total_path = get_multi_waypoint(Wptz, 20, 1)

    while i < len(Wptz) - 1:

        # Plot the results
        plt.plot(Wptz[i].x, Wptz[i].y, 'kx')
        plt.plot(Wptz[i + 1].x, Wptz[i + 1].y, 'kx')
        i += 1

    plt.plot(total_path[:, 0], total_path[:, 1], 'b-')
    print(total_path)
    print(is_path_valid(total_path, 10, 1))

    plt.grid(True)
    plt.axis("equal")
    plt.title('Dubin\'s Curves Trajectory Generation')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.show()


if __name__ == '__main__':
    main()
